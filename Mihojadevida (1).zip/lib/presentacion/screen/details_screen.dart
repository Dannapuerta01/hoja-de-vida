import 'dart:html';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:mihojadevida/presentacion/screen/home_screen.dart';

class DetailsScreen extends StatelessWidget {
  static const String name = 'detailsScreen'; // 'String' es más explícito
  const DetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Hoja de Vida"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: const CircleAvatar(
              radius: 35,
              backgroundImage: AssetImage("assets/images/fotoCedula.jpeg"),
            ),
            title: Text(
              "Danna isabel puerta urango",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              "Estudiante de Ingeniería de Software",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          //Correo
          const Divider(),
          ListTile(
            leading: const Icon(Icons.email_outlined),
            title: Text(
              "Correo",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text("dannapuerta11@gmail.com"),
          ),

          //Teléfono
          ListTile(
            leading: const Icon(Icons.phone_outlined),
            title: Text(
              "Teléfono",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text("312 852 9014"),
          ),

          //Ubicación
          ListTile(
            leading: const Icon(Icons.location_on_outlined),
            title: Text(
              "Ubicación",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text("Chigorodo, Antioquia - Colombia"),
          ),

          //Cédula
          ListTile(
            leading: const Icon(Icons.badge_outlined),
            title: Text(
              "Cédula",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text("1.037.120.133"),
          ),

          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 10),

          // Sobre mí
          Text(
            "Sobre mí",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Soy estudiante de Ingenieria en Software con conocimiento en Herramientas de diseño. Me considero un alumna disciplinad y con ganas de seguir aprendiendo mas en tecnologia.",
          ),

          const SizedBox(height: 20),

          // Experiencia
          Text(
            "Experiencia",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 10),
          const Text("- Heladeria"),
          const Text("- almacen de sandalias"),
          const Text("- Atención al cliente"),

          const SizedBox(height: 20),

          // Habilidades
          Text(
            "Referencias",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),

          SizedBox(height: 10),
          SizedBox(height: 10),
          Text("-Ana urango-3137592132"),
          Text("-Elizabeth martinez-3108337351 "),
          Text("-Rodrigo borja-3052747269"),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
