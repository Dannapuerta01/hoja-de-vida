import 'package:go_router/go_router.dart';
import 'package:mihojadevida/presentacion/screen/home_screen.dart';
import 'package:mihojadevida/presentacion/screen/details_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      name: HomeScreen.name,
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/details',
      name: DetailsScreen.name,
      builder: (context, state) => const DetailsScreen(),
    ),
  ],
);
