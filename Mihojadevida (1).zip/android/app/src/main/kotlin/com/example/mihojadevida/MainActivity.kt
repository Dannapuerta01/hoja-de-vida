package com.example.mihojadevida

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
